#include <iostream>

using namespace std;

class Person
{
  string firstName;
  string lastName;

public:
  Person(string firstName, string lastName)
  {
    cout<<"Person Constructor called"<<endl;
    this->firstName = firstName;
    this->lastName = lastName;
  }

  ~Person()
  {
    cout << "Destructor Called" << endl;
  }

  Person(const Person &obj)
  {
    cout << "Copy constructor called" << endl;
    this->firstName = obj.firstName;
    this->lastName = obj.lastName;
  }

  void operator=(const Person &obj)
  {
    cout << "Assignment operator called" << endl;
    this->firstName = obj.firstName;
    this->lastName = obj.lastName;
  }
  void setFirstName(string firstName)
  {
    this->firstName = firstName;
  }
  void setLastName(string lastName)
  {
    this->lastName = lastName;
  }
  string getLastName()
  {
    return lastName;
  }
  string getFirstName()
  {
    return firstName;
  }

};

class Employee : public Person
{
    string employee_ID;

    public:
    Employee(string firstName, string lastName, string eID): Person(firstName, lastName){
        cout<<"Employee Constructor called"<<endl;
        this->employee_ID =eID;
    }
};

class Manager : public Employee{};

class Director : public Employee{};

int main()
{
  Person p1("Aditi", "Jain");
  Employee e1("Alexa", "chan", "123");


  cout << p1.getFirstName() << " " << p1.getLastName() << endl;
  cout << e1.getFirstName() << " " << e1.getLastName() <<endl;


  return 0;
}
