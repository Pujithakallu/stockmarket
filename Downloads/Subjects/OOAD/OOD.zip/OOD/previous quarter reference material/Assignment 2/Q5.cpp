#include <iostream>
#include <vector>

using namespace std;

class Person
{
    string firstName;
    string lastName;

public:
    Person(string firstName, string lastName)
    {
        this->firstName = firstName;
        this->lastName = lastName;
    }

    ~Person()
    {
        cout << "Destructor Called" << endl;
    }

    Person(const Person &obj)
    {
        cout << "Copy constructor called" << endl;
        this->firstName = obj.firstName;
        this->lastName = obj.lastName;
    }

    void operator=(const Person &obj)
    {
        cout << "Assignment operator called" << endl;
        this->firstName = obj.firstName;
        this->lastName = obj.lastName;
    }
    void setFirstName(string firstName)
    {
        this->firstName = firstName;
    }
    void setLastName(string lastName)
    {
        this->lastName = lastName;
    }
    string getLastName()
    {
        return lastName;
    }
    string getFirstName()
    {
        return firstName;
    }

    virtual string toString()
    {
        string toStr = "Name: " + this->firstName + " " + this->lastName ;
        return toStr;
    }
};

class Employee : public Person
{
    string employee_ID;
    
    public:

    Employee(string firstName, string lastName, string eID) : Person(firstName, lastName)
    {
        this->employee_ID = eID;
    }

    virtual string toString()
    {
        string toStr = "Employee ID: "+ this->employee_ID +" "+ Person::toString();
        return toStr;
    }
};

class Manager : public Employee
{
    public:
     Manager(string firstName, string lastName, string eID) : Employee(firstName, lastName, eID){}
    virtual string toString()
    {
        string toStr = "Manager's "+Employee::toString();
        return toStr;
    }
};

class Director : public Employee
{
    public:
    Director(string firstName, string lastName, string eID) :  Employee(firstName, lastName, eID){}

    virtual string toString()
    {
        string toStr = "Director's "+Employee::toString();
        return toStr;
    }
};

int main()
{
    vector<Person *> person;

    person.push_back(new Employee("Charles","Xavier","123"));
    person.push_back(new Manager("Aditi","Jain","777"));
    person.push_back(new Director("Saurabh","Vijay","231"));
    person.push_back(new Employee("Alice","Dove","111"));
    person.push_back(new Manager("Tom","Cruise","321"));
    person.push_back(new Director("Kelly","B","456"));

    for(auto x : person)
    {
        cout<<x->toString()<<endl;
    }
    return 0;
}
