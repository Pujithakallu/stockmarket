#include <iostream>

using namespace std;

class Person
{
  string firstName;
  string lastName;
  string initials;

public:
  
  Person(string firstName, string lastName) : Person(firstName, lastName, initials)
  {
    this->initials = firstName.substr(0,1)+lastName.substr(0,1) ;
  }

  Person(string firstName, string lastName, string initials)
  {
    this->firstName = firstName;
    this->lastName = lastName;
    this->initials = initials;
  }

  ~Person()
  {
    cout << "Destructor Called" << endl;
  }

  Person(const Person &obj)
  {
    cout << "Copy constructor called" << endl;
    firstName = obj.firstName;
    lastName = obj.lastName;
    initials = obj.initials;
  }

  void operator=(const Person &obj)
  {
    cout << "Assignment operator called" << endl;
    firstName = obj.firstName;
    lastName = obj.lastName;
    initials = obj.initials;
  }
  void setFirstName(string firstName)
  {
    this->firstName = firstName;
  }
  void setLastName(string lastName)
  {
    this->lastName = lastName;
  }
  void setInitials(string initials){
      this->initials = initials;
  }
  string getInitials(){
      return initials;
  }
  string getLastName()
  {
    return lastName;
  }
  string getFirstName()
  {
    return firstName;
  }

};

int main()
{
  Person p1("Aditi", "Jain","AJ");
  p1.setFirstName("Adi");
  Person p2("Alex", "Samson");

  cout << p1.getFirstName() << " " << p1.getLastName() <<" "<< p1.getInitials()<< endl;
  cout << p2.getFirstName() << " " << p2.getLastName() <<" "<< p2.getInitials()<<endl;

  return 0;
}
