#include <iostream>

using namespace std;

class Person
{
    string firstName;
    string lastName;

public:
    Person(string firstName, string lastName)
    {
        this->firstName = firstName;
        this->lastName = lastName;
    }

    ~Person()
    {
       cout << "Destructor Called" << endl;
    }

    Person(const Person &obj)
    {
        cout << "Copy constructor called" << endl;
        this->firstName = obj.firstName;
        this->lastName = obj.lastName;
    }

    void operator=(const Person &obj)
    {
        cout << "Assignment operator called" << endl;
        this->firstName = obj.firstName;
        this->lastName = obj.lastName;
    }

    void setFirstName(string firstName)
    {
        this->firstName = firstName;
    }
    void setLastName(string lastName)
    {
        this->lastName = lastName;
    }
    string getLastName()
    {
        return lastName;
    }
    string getFirstName()
    {
        return firstName;
    }

    virtual string toString()
    {
        string toStr = "Name: " + this->firstName + " " + this->lastName ;
        return toStr;
    }
};

class Employee : public Person
{
    string employee_ID;

public:
    Employee(string firstName, string lastName, string eID) : Person(firstName, lastName)
    {
        this->employee_ID = eID;
    }

    string toString()
    {
        string toStr = "Employee ID: " + this->employee_ID + " " + Person::toString();
        return toStr;
    }
};

class Manager : public Employee
{
public:
    Manager(string firstName, string lastName, string eID) : Employee(firstName, lastName, eID) {}
    virtual string toString()
    {
        string toStr = "Manager's " + Employee::toString();
        return toStr;
    }
};

class Director : public Employee
{
public:
    Director(string firstName, string lastName, string eID) : Employee(firstName, lastName, eID) {}

    virtual string toString()
    {
        string toStr = "Director's " + Employee::toString();
        return toStr;
    }
};

int main()
{
    Person *p1 = new Person("Aditi", "Jain");
    p1->setLastName("Vijaywargia");
    p1->setFirstName("Adi");
    cout <<"Using getFirstName() and getLastName() "<< p1->getFirstName() << " " << p1->getLastName() << endl;
    cout << "Person Class toString() --- > " << p1->toString() << endl;

    Person *p3 = new Employee("Alex", "Doe", "123");
    cout << "Employee Class toString() --- > " << p3->toString() << endl;

    Manager m1("Lizzie", "Mcguire", "786");
    Director d1("Alice", "Peterson", "999");

    p1 = &m1;
    p3 = &d1;

    cout << "Manager Class toString() --- > " << p1->toString() << endl;
    cout << "Director Class toString() --- > " << p3->toString() << endl;

    return 0;
}
