#include <iostream>

using namespace std;

class Person
{
  string firstName;
  string lastName;

public:
  Person(string firstName, string lastName)
  {
    cout << "Constructor called" << endl;
    this->firstName = firstName;
    this->lastName = lastName;
  }

  ~Person()
  {
    cout << "Destructor Called" << endl;
  }

  Person(const Person &obj)
  {
    cout << "Copy constructor called" << endl;
    this->firstName = obj.firstName;
    this->lastName = obj.lastName;
  }

  void operator=(const Person &obj)
  {
    cout << "Assignment operator called" << endl;
    this->firstName = obj.firstName;
    this->lastName = obj.lastName;
  }
  void setFirstName(string firstName)
  {
    this->firstName = firstName;
  }
  void setLastName(string lastName)
  {
    this->lastName = lastName;
  }
  string getLastName()
  {
    return lastName;
  }
  string getFirstName()
  {
    return firstName;
  }

};

int main()
{
  Person p1("Alex", "John");
  
  cout <<"Name: "<< p1.getFirstName() << " " << p1.getLastName() << endl;
  
  p1.setLastName("Watson");
  p1.setFirstName("Alexa");
  Person p2("Peter", "Pan");
  Person p3 = p1;
  p1 = p3;

  cout <<"Name: "<< p1.getFirstName() << " " << p1.getLastName() << endl;
  cout <<"Name: "<< p2.getFirstName() << " " << p2.getLastName() << endl;
  cout <<"Name: "<< p3.getFirstName() << " " << p3.getLastName() << endl;

  return 0;
}
