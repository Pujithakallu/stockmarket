#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Exception
{

public:
   Exception(const string &msg) : msg_(msg) {}
   ~Exception() {}

   string what() const { return (msg_); }

private:
   string msg_;
};

int main()
{
   char myarray[10];
   try
   {
      for (int n = 0; n <= 10; n++)
      {
         if (n > 9)
            throw(Exception("Out of Range"));
         myarray[n] = 'z';
      }
   }
   catch (Exception &e)
   {
      cout << "You threw an exception: " << e.what() << endl;
   }
}
