#include "String.h"

int main()
{
	MyString a = "cat";
	MyString b = "dog";
	MyString c = a + b;
	cout << a << "+" << b << "= " << c << endl;

	MyString d = "apple";
	MyString e = "oranges";
	MyString f = d + e;
	cout << d <<"+" << e << "= " << f << endl;

	MyString g = "Class";
	MyString h = "Class";

	MyString i = h;

	if (strcmp(a, b))
		cout << a <<" and "<< b << "=> Strings are equal" << endl;
	else
		cout << a <<" and "<< b << "=> Strings are not equal" << endl;
	
	if (strcmp(g, h))
		cout << g <<" and "<< h << "=> Strings are equal" << endl;
	else
		cout << g <<" and "<< h << "=> Strings are not equal" << endl;

	return 0;
}