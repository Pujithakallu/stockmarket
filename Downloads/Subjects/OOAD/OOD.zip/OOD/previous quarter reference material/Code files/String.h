#include <iostream>
#include <ostream>
#include <string.h>

using namespace std;

class MyString
{
private:
	char *str = NULL;
	unsigned int size = 0;

public:
	MyString() : str(NULL), size(0) // default constructor
	{
	}

	MyString(const char *const buffer) // constructor
	{
		size = strlen(buffer);
		str = new char[size + 1];
		strncpy_s(str, size + 1, buffer, size);
	}

	MyString(const MyString &obj) // copy constructor
	{
		cout << "Copy constructor called." << endl;
		size = obj.size;
		str = new char[size + 1];
		strncpy_s(str, size + 1, obj.str, size);
	}

	MyString(MyString &&obj) // move constructor
	{
		if (str != nullptr)
		{
			delete[] str;
		}
		size = 0; // cleanup any existing data

		// Copy data from the incoming object
		size = obj.size;

		// Transfer ownership of char buffer from incoming object to this object
		str = obj.str;
		obj.str = nullptr;
	}

	MyString operator+(const MyString &obj) // concatenation
	{
		MyString s;
		s.size = this->size + obj.size;
		s.str = new char[s.size + 1];
		//cout<<s.size;
		for (int i = 0, j = 0, k = 0; i < s.size;)
		{
			if (j < this->size)
			{
				s.str[i] = this->str[j];
				j++;
				i++;
			}
			if (k < obj.size)
			{
				s.str[i] = obj.str[k];
				i++;
				k++;
			}
		}
		s.str[s.size] = '\0';

		return s;
	}

	unsigned int length()
	{
		return size;
	}

	const char *c_str() const
	{
		return str;
	}

	~MyString() // destructor
	{
		if (str != nullptr)
		{
			delete[] str;
		}
		size = 0;
	}

	char *getStr()
	{
		return this->str;
	}
};

std::ostream &operator<<(std::ostream &cout, const MyString &obj)
{
	cout << obj.c_str();
	return cout;
}

bool strcmp(MyString &obj1, MyString &obj2)
{
	int len1 = obj1.length();
	int len2 = obj2.length();

	if (len1 != len2)
	{
		return false;
	}
	if (len1 == len2)
	{
		char *X = obj1.getStr();
		char *Y = obj2.getStr();
		for (int i = 0; i < len1; i++)
		{
			if (X[i] != Y[i])
			{
				return false;
			}
		}
	}
	return true;
}
