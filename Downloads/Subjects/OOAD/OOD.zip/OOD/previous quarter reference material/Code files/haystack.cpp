#include <iostream>

using namespace std;

class Solution
{
public:
    string findNeedleAndReplace(string haystack, string needle, string replacement)
    {

        bool flag = true;
        while (flag)
        {
            size_t found = haystack.find(needle); //Searches the string for the first occurrence of the needle
            if (found != string::npos)            
            {
                haystack.replace(found, needle.length(), replacement); //Replace the needle using the replace() function
            }
            else
            {
                flag = false;
            }
        }

        return haystack;
    }
};

int main()
{
    string res;
    string haystack;
    string needle;
    string replace;
    cout << "Please enter Haystack, needle and replacement strings" << endl;
    cout << "Haystack: ";
    getline(cin, haystack);
    cout << "Needle: ";
    getline(cin, needle);
    cout << "Replacement: ";
    getline(cin, replace);

    Solution obj;
    res = obj.findNeedleAndReplace(haystack, needle, replace);
    cout << "Before replacement: " << haystack << endl;
    cout << "Needle : " << needle << endl;
    cout << "After replacement: " << res << endl;

    return 0;
}
